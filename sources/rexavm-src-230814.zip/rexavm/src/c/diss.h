#ifndef __DISS_H
#define __DISS_H
extern ub2 disassemble(ub2 start, ub2 end);
#endif

