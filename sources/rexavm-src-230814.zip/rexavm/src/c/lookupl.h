#ifndef _LOOKUPLST_H
#define _LOOKUPLST_H
extern ub1 lookupLST (char *word, ub2 len, ub1 *table);
#endif
