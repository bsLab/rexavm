// Automatically created on Feb  8 2023
#ifndef __VM_CODE_H
#define __VM_CODE_H
enum OP_CODES { 
  OP_DUP=0x2d       /* dup -> 45 */,
  OP_TWODUP=0x4       /* 2dup -> 4 */,
  OP_DROP=0xb       /* drop -> 11 */,
  OP_TWODROP=0x34       /* 2drop -> 52 */,
  OP_SWAP=0x46       /* swap -> 70 */,
  OP_TWOSWAP=0x2e       /* 2swap -> 46 */,
  OP_OVER=0x4e       /* over -> 78 */,
  OP_TWOOVER=0x2f       /* 2over -> 47 */,
  OP_ROT=0x3       /* rot -> 3 */,
  OP_TWOROT=0x2       /* 2rot -> 2 */,
  OP_CMINDUP=0x10       /* -dup -> 16 */,
  OP_PICK=0x43       /* pick -> 67 */,
  OP_CGTF=0x1d       /* >f -> 29 */,
  OP_FCGT=0x56       /* f> -> 86 */,
  OP_F=0x18       /* f -> 24 */,
  OP_FDROP=0x51       /* fdrop -> 81 */,
  OP_FPICK=0x30       /* fpick -> 48 */,
  OP_CPLU=0x4b       /* + -> 75 */,
  OP_TWOCPLU=0x2c       /* 2+ -> 44 */,
  OP_CMIN=0x48       /* - -> 72 */,
  OP_TWOCMIN=0x14       /* 2- -> 20 */,
  OP_CMUL=0x13       /* * -> 19 */,
  OP_TWOCMUL=0x5b       /* 2* -> 91 */,
  OP_CQUO=0x44       /* / -> 68 */,
  OP_TWOCQUO=0xc       /* 2/ -> 12 */,
  OP_MOD=0x41       /* mod -> 65 */,
  OP_TWOMOD=0x9       /* 2mod -> 9 */,
  OP_MAX=0x39       /* max -> 57 */,
  OP_TWOMAX=0x57       /* 2max -> 87 */,
  OP_MIN=0x21       /* min -> 33 */,
  OP_TWOMIN=0x47       /* 2min -> 71 */,
  OP_ABS=0x26       /* abs -> 38 */,
  OP_TWOABS=0x5d       /* 2abs -> 93 */,
  OP_MINUS=0x11       /* minus -> 17 */,
  OP_TWOMINUS=0x3d       /* 2minus -> 61 */,
  OP_AND=0x27       /* and -> 39 */,
  OP_TWOAND=0x2a       /* 2and -> 42 */,
  OP_OR=0x5c       /* or -> 92 */,
  OP_TWOOR=0x15       /* 2or -> 21 */,
  OP_XOR=0x2b       /* xor -> 43 */,
  OP_TWOXOR=0x49       /* 2xor -> 73 */,
  OP_CEQ=0x53       /* = -> 83 */,
  OP_TWOCEQ=0x4d       /* 2= -> 77 */,
  OP_CLT=0x37       /* < -> 55 */,
  OP_TWOCLT=0x31       /* 2< -> 49 */,
  OP_CGT=0x7       /* > -> 7 */,
  OP_TWOCGT=0x5e       /* 2> -> 94 */,
  OP_ZEROCLT=0xa       /* 0< -> 10 */,
  OP_ZEROCEQ=0x16       /* 0= -> 22 */,
  OP_CDOT=0x17       /* . -> 23 */,
  OP_CDOTCSTR=0x50       /* ." -> 80 */,
  OP_CDOTS=0x52       /* .s -> 82 */,
  OP_TWOCDOT=0x1a       /* 2. -> 26 */,
  OP_CR=0x32       /* cr -> 50 */,
  OP_FETCH=0x1c       /* @ -> 28 */,
  OP_TWOFETCH=0x40       /* 2@ -> 64 */,
  OP_SFETCH=0x0       /* s@ -> 0 */,
  OP_SCSTR=0x61       /* s" -> 97 */,
  OP_STORE=0x3c       /* ! -> 60 */,
  OP_TWOSTORE=0x64       /* 2! -> 100 */,
  OP_SSTORE=0x42       /* s! -> 66 */,
  OP_TWOEXT=0x35       /* 2ext -> 53 */,
  OP_TWORED=0x3e       /* 2red -> 62 */,
  OP_CDOLL=0x1e       /* $ -> 30 */,
  OP_CELLCPLU=0x20       /* cell+ -> 32 */,
  OP_ARRAY=0x38       /* array -> 56 */,
  OP_DEFINE=0x33       /* : -> 51 */,
  OP_DEFRET=0x24       /* ; -> 36 */,
  OP_RETURN=0x28       /* return -> 40 */,
  OP_DO=0x60       /* do -> 96 */,
  OP_LOOP=0x8       /* loop -> 8 */,
  OP_CPLULOOP=0x3f       /* +loop -> 63 */,
  OP_LEAVE=0x62       /* leave -> 98 */,
  OP_I=0x23       /* i -> 35 */,
  OP_J=0x22       /* j -> 34 */,
  OP_IF=0x55       /* if -> 85 */,
  OP_ELSE=0x1f       /* else -> 31 */,
  OP_ENDIF=0x3a       /* endif -> 58 */,
  OP_BEGIN=0x4a       /* begin -> 74 */,
  OP_AGAIN=0x63       /* again -> 99 */,
  OP_UNTIL=0xf       /* until -> 15 */,
  OP_WHILE=0x1       /* while -> 1 */,
  OP_VAR=0x25       /* var -> 37 */,
  OP_TWOVAR=0x5a       /* 2var -> 90 */,
  OP_CONST=0x45       /* const -> 69 */,
  OP_FORGET=0x4f       /* forget -> 79 */,
  OP_SEND=0x54       /* send -> 84 */,
  OP_SENDN=0x6       /* sendn -> 6 */,
  OP_RECEIVE=0x59       /* receive -> 89 */,
  OP_READ=0xd       /* read -> 13 */,
  OP_WRITE=0x1b       /* write -> 27 */,
  OP_LOAD=0x12       /* load -> 18 */,
  OP_SAVE=0x29       /* save -> 41 */,
  OP_OUT=0x5f       /* out -> 95 */,
  OP_INP=0x5       /* inp -> 5 */,
  OP_SLEEP=0x19       /* sleep -> 25 */,
  OP_YIELD=0x58       /* yield -> 88 */,
  OP_BASE=0x4c       /* base -> 76 */,
  OP_ONE=0x36       /* one -> 54 */,
  OP_AWAIT=0x3b       /* await -> 59 */,
  OP_END=0xe       /* end -> 14 */,
  OP_CALL=0x65 /* prefix op: call word */,
  OP_FCALL=0x66 /* prefix op: call word */,
  OP_BRANCH=0x67 /* prefix op: call word */,
  OP_INDIRECT=0x68 /* prefix op: indirect address resolving */,
  OP_NOP=0x69 /* nop */,
  OP_LIT=0x6a /* short literal */,
  OP_TWOLIT=0x6b /* long literal */
};
extern char OPSTRTABLE[][8];
#define OPSTRTABLEGEN char OPSTRTABLE[][8]={\
\
    "s@" /*0*/,\
    "while" /*1*/,\
    "2rot" /*2*/,\
    "rot" /*3*/,\
    "2dup" /*4*/,\
    "inp" /*5*/,\
    "sendn" /*6*/,\
    ">" /*7*/,\
    "loop" /*8*/,\
    "2mod" /*9*/,\
    "0<" /*10*/,\
    "drop" /*11*/,\
    "2/" /*12*/,\
    "read" /*13*/,\
    "end" /*14*/,\
    "until" /*15*/,\
    "-dup" /*16*/,\
    "minus" /*17*/,\
    "load" /*18*/,\
    "*" /*19*/,\
    "2-" /*20*/,\
    "2or" /*21*/,\
    "0=" /*22*/,\
    "." /*23*/,\
    "f" /*24*/,\
    "sleep" /*25*/,\
    "2." /*26*/,\
    "write" /*27*/,\
    "@" /*28*/,\
    ">f" /*29*/,\
    "$" /*30*/,\
    "else" /*31*/,\
    "cell+" /*32*/,\
    "min" /*33*/,\
    "j" /*34*/,\
    "i" /*35*/,\
    ";" /*36*/,\
    "var" /*37*/,\
    "abs" /*38*/,\
    "and" /*39*/,\
    "return" /*40*/,\
    "save" /*41*/,\
    "2and" /*42*/,\
    "xor" /*43*/,\
    "2+" /*44*/,\
    "dup" /*45*/,\
    "2swap" /*46*/,\
    "2over" /*47*/,\
    "fpick" /*48*/,\
    "2<" /*49*/,\
    "cr" /*50*/,\
    ":" /*51*/,\
    "2drop" /*52*/,\
    "2ext" /*53*/,\
    "one" /*54*/,\
    "<" /*55*/,\
    "array" /*56*/,\
    "max" /*57*/,\
    "endif" /*58*/,\
    "await" /*59*/,\
    "!" /*60*/,\
    "2minus" /*61*/,\
    "2red" /*62*/,\
    "+loop" /*63*/,\
    "2@" /*64*/,\
    "mod" /*65*/,\
    "s!" /*66*/,\
    "pick" /*67*/,\
    "/" /*68*/,\
    "const" /*69*/,\
    "swap" /*70*/,\
    "2min" /*71*/,\
    "-" /*72*/,\
    "2xor" /*73*/,\
    "begin" /*74*/,\
    "+" /*75*/,\
    "base" /*76*/,\
    "2=" /*77*/,\
    "over" /*78*/,\
    "forget" /*79*/,\
    ".\"" /*80*/,\
    "fdrop" /*81*/,\
    ".s" /*82*/,\
    "=" /*83*/,\
    "send" /*84*/,\
    "if" /*85*/,\
    "f>" /*86*/,\
    "2max" /*87*/,\
    "yield" /*88*/,\
    "receive" /*89*/,\
    "2var" /*90*/,\
    "2*" /*91*/,\
    "or" /*92*/,\
    "2abs" /*93*/,\
    "2>" /*94*/,\
    "out" /*95*/,\
    "do" /*96*/,\
    "s\"" /*97*/,\
    "leave" /*98*/,\
    "again" /*99*/,\
    "2!" /*100*/\
  };
#endif
