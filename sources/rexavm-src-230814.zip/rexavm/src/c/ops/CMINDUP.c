STACKCHECK(1);a=STACKTOP(1);PUSH(a);PUSH(a);
pc++;DISPATCH(); /* -dup */
