STACKCHECK(2);a=STACKTOP(2);PUSH(a);
pc++;DISPATCH(); /* over */