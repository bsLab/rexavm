STACKCHECK(1);POP();
pc++;DISPATCH(); /* drop */