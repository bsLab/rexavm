STACKCHECK(2);a=POP();b=POP();
PUSH(a);PUSH(b);
pc++;DISPATCH(); /* swap */