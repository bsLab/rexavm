vmerror=ENOTIMPLEMENTED; goto onerror;
 /* receive */