FSTACKCHECK(1);a=FPOP();PUSH(a);
pc++;DISPATCH(); /* f> */