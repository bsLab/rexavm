STACKCHECK(1);a=POP();
PUSH(-a);
pc++;DISPATCH(); /* minus */