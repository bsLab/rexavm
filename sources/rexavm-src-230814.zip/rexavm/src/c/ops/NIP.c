STACKCHECK(2);a=POP();POP();
PUSH(a);
pc++;DISPATCH(); /* nip */
