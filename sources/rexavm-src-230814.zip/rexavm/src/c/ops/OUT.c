STACKCHECK(1); OUT(POP());
pc++;DISPATCH(); /* out */