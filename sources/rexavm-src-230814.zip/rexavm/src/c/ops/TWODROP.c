STACKCHECK(2);POP2();
pc++;DISPATCH(); /* 2drop */