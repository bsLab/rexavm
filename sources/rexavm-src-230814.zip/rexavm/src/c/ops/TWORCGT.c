RSTACKCHECK(2);da=RPOP2();PUSH2(da);
pc++;DISPATCH(); /* r> */
