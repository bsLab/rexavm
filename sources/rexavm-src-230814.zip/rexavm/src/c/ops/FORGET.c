vmerror=ENOTIMPLEMENTED; goto onerror;
 /* forget */