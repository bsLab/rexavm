STACKCHECK(4);da=POP2();db=POP2();
PUSH2(da^db);
pc++;DISPATCH(); /* 2xor */