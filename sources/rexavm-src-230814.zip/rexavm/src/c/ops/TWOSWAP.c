STACKCHECK(4);da=POP2();db=POP2();
PUSH2(da);PUSH2(db);pc++;DISPATCH(); /* 2swap */