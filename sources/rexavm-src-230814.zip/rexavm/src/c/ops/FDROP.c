STACKCHECK(1);a=POP();FSTACKCHECK(a);fstop-=a;
pc++;DISPATCH(); /* f */