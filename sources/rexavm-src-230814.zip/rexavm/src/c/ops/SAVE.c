vmerror=ENOTIMPLEMENTED; goto onerror;
 /* save */