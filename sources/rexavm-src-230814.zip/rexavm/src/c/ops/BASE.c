STACKCHECK(1);vmbase=POP();
pc++;DISPATCH(); /* base */