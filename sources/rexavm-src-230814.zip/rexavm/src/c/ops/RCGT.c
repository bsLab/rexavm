RSTACKCHECK(1);a=RPOP();PUSH(a);
pc++;DISPATCH(); /* r> */
