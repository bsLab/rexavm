STACKCHECK(1);a=POP();PUSH(a<0?1:0);
pc++;DISPATCH(); /* 0< */