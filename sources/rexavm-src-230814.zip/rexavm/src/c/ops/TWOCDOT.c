STACKCHECK(2);CONSOLEFMT(vmbase==0?"%d ":"%x ",vmbase==0?(sb4)POP2():(ub4)POP2());
pc++;DISPATCH(); /* 2. */