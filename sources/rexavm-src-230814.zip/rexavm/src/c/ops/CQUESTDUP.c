STACKCHECK(1);if (STACKTOP(1)!=0) { a=STACKTOP(1);PUSH(a); };
pc++;DISPATCH(); /* -dup */
