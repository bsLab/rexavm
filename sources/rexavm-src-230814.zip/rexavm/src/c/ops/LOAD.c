vmerror=ENOTIMPLEMENTED; goto onerror;
 /* load */