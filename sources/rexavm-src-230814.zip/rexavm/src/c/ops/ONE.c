PUSH(1);
pc++;DISPATCH(); /* one */