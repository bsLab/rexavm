STACKCHECK(2);da=POP2();
PUSH2(-da);
pc++;DISPATCH(); /* 2minus */