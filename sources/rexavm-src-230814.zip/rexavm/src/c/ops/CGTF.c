STACKCHECK(1);a=POP();FPUSH(a);
pc++;DISPATCH(); /* >f */