STACKCHECK(1);a=POP();PUSH2((sb4)a);
pc++;DISPATCH(); /* 2ext */