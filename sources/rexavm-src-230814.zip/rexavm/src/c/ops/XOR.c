STACKCHECK(2);a=POP();b=POP();PUSH((sb2)((ub2)a ^ (ub2)b));
pc++;DISPATCH(); /* xor */