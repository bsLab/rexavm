STACKCHECK(2);a=POP();b=POP();PUSH(b/a);
pc++;DISPATCH(); /* / */