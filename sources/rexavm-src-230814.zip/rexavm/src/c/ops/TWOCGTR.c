STACKCHECK(2);da=POP2();RPUSH2(da);
pc++;DISPATCH(); /* 2>r */
