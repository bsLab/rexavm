STACKCHECK(2);a=POP();b=POP();PUSH(a+b);
pc++;DISPATCH(); /* + */