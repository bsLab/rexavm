STACKCHECK(1);a=POP();RPUSH(a);
pc++;DISPATCH(); /* >r */
