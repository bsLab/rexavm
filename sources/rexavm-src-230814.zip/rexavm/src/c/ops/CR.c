CONSOLENL();
pc++;DISPATCH(); /* cr */