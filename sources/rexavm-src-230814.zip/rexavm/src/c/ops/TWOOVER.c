STACKCHECK(4);da=STACKTOP2(2);PUSH2(da);
pc++;DISPATCH(); /* 2over */
