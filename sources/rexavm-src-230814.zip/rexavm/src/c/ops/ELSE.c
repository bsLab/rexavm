pc=(*(ub2*)(&code[pc+1]));
DISPATCH(); /* else */