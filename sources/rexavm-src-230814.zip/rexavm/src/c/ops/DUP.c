STACKCHECK(1);a=STACKTOP(1);
PUSH(a);
pc++;DISPATCH(); /* dup */