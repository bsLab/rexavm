local function milli () 
  return luv.milli()
end
local counter
local S=100
local start = milli()
counter = 0
local temp
for i = 1,30000*S do
  for j = 1,100 do
    temp = i + j
    counter = counter + 1
  end
end
local stop = milli()
print(temp)
print((stop-start)..' ms')
local lps = counter/(stop-start)*1000
print(counter .. ' loops '..math.floor(lps/1000)..' KLPS')
counter = counter * 11
local ips = counter/(stop-start)*1000
print(ips.. ' IPS '..math.floor(ips/1000000)..' MIPS')
