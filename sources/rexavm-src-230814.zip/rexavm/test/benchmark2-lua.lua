local function milli () 
  return os.clock()*1000
end
local counter
local S=10
local start = milli()
counter = 0
local temp
local function foo(i,j)
  temp = i + j
  counter = counter + 1
end
for i = 1,30000*S do
  for j = 1,100 do
    foo(i,j)
  end
end
local stop = milli()
print(temp)
print((stop-start)..' ms')
local lps = counter/(stop-start)*1000
print(counter .. ' loops '.. math.floor(lps/1000)..' KLPS')
counter = counter * 14
local ips = counter/(stop-start)*1000
print(ips.. ' IPS '..math.floor(ips/1000000)..' MIPS')
