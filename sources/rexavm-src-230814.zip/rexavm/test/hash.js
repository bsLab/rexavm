print=console.log
/*
  Hashtable Dictionary with in-place collision handling
  and linked collision lists (next hops)
*/
var DICTSIZE = 29 // 30,32
var NOTFOUND = -1
var dictcollision = 0
var lastfree = NOTFOUND,
    lastindex = NOTFOUND,
    lastprev = NOTFOUND

var dictionary = Array(DICTSIZE).fill(0).map(() => ({
  name:'',
  addr:0,
  size:0,
  flags:0,
  next:0
}))


function dicthash(name,length,tablesize) {
  var sum=0,i=0;
  while (i<length) { sum+=name.charCodeAt(i); i++; };
  return sum % tablesize;
}


function dictlookup(dictionary, dictsize, name, length) {
  var h = dicthash(name,length,dictsize);
  lastindex = NOTFOUND;
  lastprev  = NOTFOUND;
  if (!dictionary[h].name && !dictionary[h].next) {
    lastfree=h; return NOTFOUND;
  } else if (dictionary[h].name != name) {
    lastindex = h;
    if (dictionary[h].next==0) return NOTFOUND; // fast return
    // incremental search
    i=0;
    while (i<dictsize) {
      lastprev = h;
      h=(h+dictionary[h].next)%dictsize;i++;
      if (dictionary[h].name==name) return h;
      if (dictionary[h].next==0) { lastindex=h; return NOTFOUND; }
    }
    return NOTFOUND;
  } else return h;
}

function dictadd(dictionary, dictsize, name, length) {
  var i,h = dicthash(name,length,dictsize);
  if (!dictionary[h].name) {
    // free slot
    // allocate slot
    dictionary[h].name=name;
    return h;
  } else {
    // incremental search for free slot
    dictcollision++;
    h=dictlookup(dictionary,dictsize,name,length);
    if (h!=NOTFOUND) return h; // exists already
    if (lastfree!=NOTFOUND) {
      h = lastfree;
      dictionary[h].name=name;
      return h;
    } else if (lastindex!=NOTFOUND) {
      h=lastindex;
      i=0;
      while (i<dictsize) {
        h=(h+1)%dictsize;i++;
        if (!dictionary[h].name) {
          dictionary[lastindex].next=h-lastindex;
          dictionary[h].name=name;
          return h;
        }
      }
    }
    return NOTFOUND;
  }
}

function dictrem(dictionary, dictsize, name, length) {
  var i,h=dictlookup(dictionary,dictsize,name,length);
  if (h==NOTFOUND) return;
  dictionary[h].name=''; 
  if (dictionary[h].next && lastprev!=NOTFOUND) {
    dictionary[lastprev].next=h-lastprev
  }
}

var test = [
  'foo',
  'foo2',
  'sq',
  'permute',
  'handle',
  'serv',
  'more',
  'make',
  'backward',
  'search',
  'wardback',
  'wardckba',
]

print(test.map((s) => dicthash(s,s.length,DICTSIZE)));
print(test.map((s) => dictadd(dictionary,DICTSIZE,s,s.length)));
print(test.map((s) => dictlookup(dictionary,DICTSIZE,s,s.length)));
print(dictcollision)
var word = 'wardback'
dictrem(dictionary,DICTSIZE,word,word.length)
print(test.map((s) => dictlookup(dictionary,DICTSIZE,s,s.length)));
word = 'backward'
dictrem(dictionary,DICTSIZE,word,word.length)
print(test.map((s) => dictlookup(dictionary,DICTSIZE,s,s.length)));

